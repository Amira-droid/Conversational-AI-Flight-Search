# Flight Search & Book — Final Beautiful Build

Polish
- Refined light UI: modern cards, chips, badges, subtle gradients & focus rings.
- Route-aware carriers: **DXB⇢NYC (JFK/EWR)** and **DXB⇢LHR** include **EK, BA, AA**. Other routes show **EK, AI**.
- Everything else kept: taxes (AED 5%, INR 12%, USD 0%), coupons, seats, cancellation + refund logic, PDFs, admin.

Run
```bash
python -m venv .venv
# Windows:
.\.venv\Scriptsctivate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python app.py
# open http://127.0.0.1:5000/
```
