from flask import Flask, request, render_template, jsonify, redirect, url_for, session, send_file
import os, re, json, random, datetime as dt, io
from dateparser.search import search_dates
from dateutil import parser as duparser
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF

app = Flask(__name__)
app.secret_key = os.environ.get('APP_SECRET', 'dev-secret')

BOOKINGS = {}
COUPONS = {
    'SAVE10': {'type':'percent','value':0.10,'applies_to':'subtotal'},
    'SEAT50': {'type':'flat','value':50,'applies_to':'seat'},
    'BASE200': {'type':'flat','value':200,'applies_to':'base'}
}
TAX_RATES = {'AED':0.05,'INR':0.12,'USD':0.00}

CITY_TO_IATA = {
    'dubai':'DXB','dxb':'DXB','uae':'DXB',
    'delhi':'DEL','new delhi':'DEL','del':'DEL',
    'bengaluru':'BLR','bangalore':'BLR','blr':'BLR',
    'mumbai':'BOM','bombay':'BOM','bom':'BOM',
    'hyderabad':'HYD','hyd':'HYD',
    'chennai':'MAA','madras':'MAA','maa':'MAA',
    'london':'LHR','heathrow':'LHR','lhr':'LHR','gatwick':'LGW','lgw':'LGW',
    'new york':'JFK','nyc':'JFK','jfk':'JFK','ewr':'EWR','newark':'EWR',
    'abudhabi':'AUH','abu dhabi':'AUH','auh':'AUH',
    'sharjah':'SHJ','shj':'SHJ'
}

def normalize_airport(token):
    t = token.strip().lower()
    if len(t) == 3 and t.isalpha():
        return t.upper()
    return CITY_TO_IATA.get(t)

def parse_query(text):
    t = (text or '').strip()

    m_cancel = re.search(r'\bcancel\s+pnr\s+([A-Z0-9]{5,8})\b', t, re.I)
    cancel_intent = m_cancel.group(1).upper() if m_cancel else None

    m = re.search(r'\bbook\s+([A-Za-z]{2})\s*[-\s]?(\d{2,4})\b', t, re.I)
    book_intent = (m.group(1).upper(), m.group(2)) if m else None

    iata = re.findall(r'\b([A-Z]{3})\b', t)
    origin = iata[0].upper() if len(iata) >= 1 else None
    destination = iata[1].upper() if len(iata) >= 2 else None

    if not (origin and destination):
        m2 = re.search(r'from\s+([A-Za-z ]+?)\s+to\s+([A-Za-z ]+?)(?:\s|,|$)', t, re.I)
        if m2:
            origin = origin or normalize_airport(m2.group(1)) or (m2.group(1)[:3].upper())
            destination = destination or normalize_airport(m2.group(2)) or (m2.group(2)[:3].upper())

    if not (origin and destination):
        tokens = re.findall(r'[A-Za-z]{3,}', t)
        mapped = [normalize_airport(tok) for tok in tokens if normalize_airport(tok)]
        if len(mapped) >= 2:
            origin = origin or mapped[0]
            destination = destination or mapped[1]

    adults = 1
    m_ad = re.search(r'(\d+)\s*(adult|adults|pax|passengers?)', t, re.I)
    if m_ad: adults = int(m_ad.group(1))

    date = None
    dp = search_dates(t, settings={'PREFER_DATES_FROM':'future','RETURN_AS_TIMEZONE_AWARE': False})
    if dp: date = dp[0][1].date().isoformat()
    else:
        try:
            parsed = duparser.parse(t, fuzzy=True); date = parsed.date().isoformat()
        except Exception:
            pass

    return {'origin': origin, 'destination': destination, 'date': date, 'adults': adults, 'book_intent': book_intent, 'cancel_intent': cancel_intent, 'raw': text}

def pnr(n=6): return ''.join(random.choices('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', k=n))

def fabricate(origin, dest, date_iso, max_offers=8):
    if not date_iso: date_iso = dt.date.today().isoformat()
    try: base = dt.datetime.strptime(date_iso, '%Y-%m-%d')
    except Exception: base = dt.datetime.now()

    def fl(code):
        bank = {
            'AI':[101,111,113,115,117,121,127,131,301,305,307,309],
            'EK':[500,502,504,512,516,518,520,522,524,526],
            'BA':[105,107,109,111,113,115,117,119],
            'AA':[100,102,104,106,108,110,112,114]
        }.get(code, [900,901,902,903,904])
        return f'{code} {random.choice(bank)}'

    offers=[]; fare_classes=['Saver','Standard','Flex']

    orig = (origin or 'DXB').upper()
    destu = (dest or 'DEL').upper()

    # Airline set by route
    if orig == 'DXB' and destu in {'JFK','EWR','LHR'}:
        carriers = [('EK','Emirates'), ('BA','British Airways'), ('AA','American Airlines')]
    else:
        carriers = [('EK','Emirates'), ('AI','Air India')]

    for _ in range(max_offers):
        code, name = random.choice(carriers)
        dep = base.replace(hour=random.choice([1,6,8,9,12,14,18,21]), minute=random.choice([0,15,30,45]))
        dur = 7.0 if destu in {'LHR'} else (13.5 if destu in {'JFK','EWR'} else random.uniform(3.0, 15.0))
        arr = dep + dt.timedelta(hours=dur + random.uniform(-0.5,0.8))
        currency = 'AED' if orig in {'DXB','AUH','SHJ'} else ('INR' if orig in {'DEL','BOM','BLR','HYD','MAA'} else 'USD')
        base_price = (700 if currency=='AED' else 18000 if currency=='INR' else 800)
        # Long-haul uplift
        if destu in {'LHR','JFK','EWR'}: base_price *= 2.2
        price = f"{currency} {int(base_price + random.randint(-80,180))}"
        offers.append({
            'airline': f'{name} ({code})',
            'fare_class': random.choice(fare_classes),
            'flight_no': fl(code),
            'depart_airport': origin,
            'arrive_airport': dest,
            'depart_time': dep.strftime('%Y-%m-%dT%H:%M'),
            'arrive_time': arr.strftime('%Y-%m-%dT%H:%M'),
            'stops': 0 if destu in {'LHR','JFK','EWR'} else random.choice([0,0,1]),
            'price': price
        })
    return offers

def fare_currency(offer_price_str: str):
    if not offer_price_str: return 'USD'
    return offer_price_str.split()[0]

def fare_amount(offer_price_str: str):
    if not offer_price_str: return 0.0
    parts = offer_price_str.split()
    if len(parts) < 2: return 0.0
    digits = re.sub(r'[^0-9.]', '', parts[1])
    try: return float(digits)
    except: return 0.0

def compute_breakdown(details):
    currency = fare_currency(details['offer'].get('price'))
    base = fare_amount(details['offer'].get('price'))
    seat_amt = fare_amount(details.get('seat',{}).get('price','0'))
    subtotal = base + seat_amt

    coupon = details.get('coupon')
    discount = 0.0
    if coupon:
        code = coupon.get('code','').upper()
        c = COUPONS.get(code)
        if c:
            if c['type'] == 'percent':
                target = subtotal if c.get('applies_to') == 'subtotal' else (seat_amt if c.get('applies_to')=='seat' else base)
                discount = round(target * c['value'], 2)
            elif c['type'] == 'flat':
                target = c.get('applies_to')
                if target == 'seat': discount = min(seat_amt, c['value'])
                elif target == 'base': discount = min(base, c['value'])
                else: discount = min(subtotal, c['value'])

    taxable = max(subtotal - discount, 0.0)
    tax_rate = TAX_RATES.get(currency, 0.0)
    tax_amt = round(taxable * tax_rate, 2)
    total = round(taxable + tax_amt, 2)

    return {'currency': currency, 'base': base, 'seat': seat_amt, 'subtotal': round(subtotal,2),'discount': discount, 'tax_rate': tax_rate, 'tax_amt': tax_amt, 'total': total}

def compute_refund(details):
    br = compute_breakdown(details)
    currency = br['currency']; total = br['total']
    try: depart_dt = duparser.parse(details['offer']['depart_time'])
    except Exception: depart_dt = dt.datetime.utcnow()
    now = dt.datetime.utcnow(); delta_days = (depart_dt - now).days
    if delta_days >= 30: base_p = 0.05
    elif delta_days >= 14: base_p = 0.10
    elif delta_days >= 7: base_p = 0.25
    elif delta_days >= 1: base_p = 0.50
    else: base_p = 0.90
    fare_cls = details['offer'].get('fare_class','Standard')
    adj = {'Saver': 0.10, 'Standard': 0.00, 'Flex': -0.15}.get(fare_cls, 0.0)
    penalty_rate = max(0.0, min(0.95, base_p + adj))
    seat_amt = br['seat']; seat_refundable = (fare_cls == 'Flex'); forfeited_seat = 0.0 if seat_refundable else seat_amt
    base_for_refund = max(total - forfeited_seat, 0.0)
    penalty_amount = round(base_for_refund * penalty_rate, 2)
    refundable = max(base_for_refund - penalty_amount, 0.0)
    note = f"Fare: {fare_cls}. Seat {'refundable' if seat_refundable else 'non-refundable'}. Window penalty {int(base_p*100)}% + fare adj {int(adj*100)}%."
    return {'currency': currency, 'penalty_rate': penalty_rate, 'penalty_amount': penalty_amount, 'refundable': round(refundable,2), 'forfeited_seat': round(forfeited_seat,2), 'notes': note}

@app.route('/', methods=['GET','POST'])
def index():
    parsed=None; results=None; error=None
    if request.method=='POST':
        text = (request.form.get('query') or '').strip()
        bookcmd = (request.form.get('bookcmd') or '').strip()

        combined = f"{text} {bookcmd}".strip()
        if combined:
            parsed_tmp = parse_query(combined)
            if parsed_tmp.get('cancel_intent'):
                code = parsed_tmp['cancel_intent']
                return redirect(url_for('cancel_pnr', code=code))

        if bookcmd:
            m = re.search(r'\bbook\s+([A-Za-z]{2})\s*[-\s]?(\d{2,4})\b', bookcmd, re.I)
            if not m:
                error={'error':'Please type like: Book AI 117 or Cancel PNR ABC123'}
            else:
                code, num = m.group(1).upper(), m.group(2)
                last = session.get('last_offers') or []
                chosen=None
                for o in last:
                    if o.get('flight_no') and o['flight_no'].upper().replace(' ','') == f"{code}{num}":
                        chosen=o; break
                if not chosen:
                    ctx = session.get('last_ctx') or {'origin':'DXB','destination':'DEL','date':dt.date.today().isoformat()}
                    fake = fabricate(ctx['origin'], ctx['destination'], ctx['date'])
                    for o in fake:
                        if o['flight_no'].upper().replace(' ','') == f"{code}{num}":
                            chosen=o; break
                    if not chosen:
                        chosen = fake[0]; chosen['flight_no'] = f"{code} {num}"
                return redirect('/traveller?offer=' + json.dumps(chosen))

        parsed = parse_query(text)
        missing = [k for k in ['origin','destination','date'] if not parsed.get(k)]
        if missing:
            error={'error': 'Missing: ' + ', '.join(missing) + '. Example: DXB to LHR on 20 Nov 2025'}
        else:
            res = {'source':'fallback-multi','offers': fabricate(parsed['origin'], parsed['destination'], parsed['date'])}
            results=res
            session['last_offers']=res['offers']
            session['last_ctx']={'origin':parsed['origin'],'destination':parsed['destination'],'date':parsed['date']}
    return render_template('index.html', parsed=parsed, results=results, error=error)

@app.get('/traveller')
def traveller():
    offer_json = request.args.get('offer')
    try: offer = json.loads(offer_json)
    except Exception: return "Invalid offer", 400
    return render_template('traveller.html', offer=offer)

@app.post('/confirm')
def confirm():
    offer_json = request.form.get('offer')
    name = request.form.get('name',''); email = request.form.get('email',''); phone = request.form.get('phone',''); passport = request.form.get('passport','')
    try: offer = json.loads(offer_json)
    except Exception: return "Invalid offer", 400
    code = pnr()
    details={'pnr': code, 'status':'CONFIRMED', 'created_at': dt.datetime.utcnow().isoformat(), 'passenger': {'name':name,'email':email,'phone':phone,'passport':passport}, 'offer': offer}
    BOOKINGS[code] = details
    return redirect('/pnr/' + code)

@app.post('/coupon/<code>')
def apply_coupon(code):
    details = BOOKINGS.get(code)
    if not details:
        return ('PNR not found', 404)
    coupon = (request.form.get('coupon') or '').upper().strip()
    if coupon in COUPONS:
        details['coupon'] = {'code': coupon}
        BOOKINGS[code] = details
        return redirect(url_for('pnr_view', code=code))
    return ('Invalid coupon', 400)

@app.get('/cancel/<code>')
def cancel_pnr(code):
    details = BOOKINGS.get(code)
    if not details:
        return render_template('pnr.html', found=False, code=code)
    details['status'] = 'CANCELLED'
    details['cancelled_at'] = dt.datetime.utcnow().isoformat()
    details['refund'] = compute_refund(details)
    BOOKINGS[code] = details
    return redirect(url_for('pnr_view', code=code))

@app.get('/pnr/<code>')
def pnr_view(code):
    details = BOOKINGS.get(code)
    if not details:
        return render_template('pnr.html', found=False, code=code)
    breakdown = compute_breakdown(details)
    return render_template('pnr.html', found=True, details=details, breakdown=breakdown)

def generate_seatmap(rows=14, seats='ABCDEF', occupied_ratio=0.22):
    seatmap = {}
    for r in range(1, rows+1):
        for c in seats:
            seatmap[f"{r}{c}"] = (random.random() < occupied_ratio)
    return seatmap

@app.get('/seat/<code>')
def seat_get(code):
    details = BOOKINGS.get(code)
    if not details:
        return render_template('pnr.html', found=False, code=code)
    seatmap = generate_seatmap()
    currency = fare_currency(details['offer'].get('price'))
    base_price = random.choice([60,75,90,110,130,150])
    return render_template('seat.html', details=details, seatmap=seatmap, base_price=base_price, currency=currency)

@app.post('/seat/<code>')
def seat_post(code):
    details = BOOKINGS.get(code)
    if not details:
        return render_template('pnr.html', found=False, code=code)
    seat = request.form.get('seat')
    price = request.form.get('price')
    currency = fare_currency(details['offer'].get('price'))
    if not seat:
        return redirect(url_for('seat_get', code=code))
    details['seat'] = {'seat_no': seat, 'price': f"{currency} {price}"}
    BOOKINGS[code] = details
    return render_template('seat_confirm.html', details=details)

@app.get('/admin')
def admin():
    data = []
    for code, d in BOOKINGS.items():
        br = compute_breakdown(d)
        data.append({
            'pnr': code,
            'name': d['passenger']['name'],
            'route': f"{d['offer']['depart_airport']}→{d['offer']['arrive_airport']}",
            'flight': d['offer']['flight_no'],
            'status': d.get('status','CONFIRMED'),
            'currency': br['currency'],
            'total': br['total'],
            'refund': (d.get('refund',{}) or {}).get('refundable')
        })
    data.sort(key=lambda x: x['pnr'])
    return render_template('admin.html', rows=data)

def _draw_common_header(c, details, title):
    width, height = A4
    y = height - 50
    c.setFont('Helvetica-Bold', 16); c.drawString(40, y, title); y -= 30
    c.setFont('Helvetica', 11); c.drawString(40, y, f"PNR: {details['pnr']}"); y -= 16
    c.drawString(40, y, f"Passenger: {details['passenger']['name']}  |  Email: {details['passenger']['email']}"); y -= 22
    qr_data = json.dumps({ 'pnr': details['pnr'], 'airline': details['offer']['airline'], 'flight': details['offer']['flight_no'], 'from': details['offer']['depart_airport'], 'to': details['offer']['arrive_airport'], 'depart': details['offer']['depart_time'], 'name': details['passenger']['name'], 'status': details.get('status','CONFIRMED') })
    qrw = qr.QrCodeWidget(qr_data); bounds = qrw.getBounds()
    size = 120; w = bounds[2]-bounds[0]; h = bounds[3]-bounds[1]
    d = Drawing(size, size, transform=[size/w,0,0,size/h,0,0]); d.add(qrw)
    renderPDF.draw(d, c, width-180, y-60); c.setFont('Helvetica', 8); c.drawString(width-180, y-70, 'Scan for booking summary')
    return y

@app.get('/receipt/<code>')
def receipt_pdf(code):
    details = BOOKINGS.get(code)
    if not details: return ('PNR not found', 404)
    br = compute_breakdown(details)

    buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=A4)
    y = _draw_common_header(c, details, 'Flight Booking Receipt')

    c.setFont('Helvetica-Bold', 12); c.drawString(40, y, 'Itinerary'); y -= 18
    c.setFont('Helvetica', 11)
    c.drawString(40, y, f"{details['offer']['airline']}  —  {details['offer']['flight_no']} · {details['offer'].get('fare_class','Standard')}"); y -= 16
    c.drawString(40, y, f"{details['offer']['depart_airport']} → {details['offer']['arrive_airport']}"); y -= 16
    c.drawString(40, y, f"Depart: {details['offer']['depart_time']}   Arrive: {details['offer']['arrive_time']}"); y -= 22

    c.setFont('Helvetica-Bold', 12); c.drawString(40, y, 'Fare breakdown'); y -= 18
    c.setFont('Helvetica', 11)
    c.drawString(40, y, f"Base Fare: {br['currency']} {br['base']:,.2f}"); y -= 16
    if br['seat'] > 0: c.drawString(40, y, f"Seat Fee: {br['currency']} {br['seat']:,.2f}"); y -= 16
    c.drawString(40, y, f"Subtotal: {br['currency']} {br['subtotal']:,.2f}"); y -= 16
    if br['discount'] > 0: c.drawString(40, y, f"Coupon Discount: -{br['currency']} {br['discount']:,.2f}"); y -= 16
    if br['tax_rate'] > 0: c.drawString(40, y, f"Tax ({int(br['tax_rate']*100)}%): {br['currency']} {br['tax_amt']:,.2f}"); y -= 16
    c.setFont('Helvetica-Bold', 12); c.drawString(40, y, f"Total: {br['currency']} {br['total']:,.2f}")

    c.showPage(); c.save(); buf.seek(0)
    return send_file(buf, mimetype='application/pdf', as_attachment=True, download_name=f"receipt_{details['pnr']}.pdf")

@app.get('/receipt_cancel/<code>')
def receipt_cancel_pdf(code):
    details = BOOKINGS.get(code)
    if not details: return ('PNR not found', 404)
    br = compute_breakdown(details)

    buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=A4)
    y = _draw_common_header(c, details, 'Cancellation Receipt')

    c.setFont('Helvetica-Bold', 12); c.drawString(40, y, 'Status'); y -= 18
    c.setFont('Helvetica', 11); c.drawString(40, y, f"Status: {details.get('status','CONFIRMED')}"); y -= 16
    if details.get('cancelled_at'): c.drawString(40, y, f"Cancelled at: {details['cancelled_at']}"); y -= 20

    c.setFont('Helvetica-Bold', 12); c.drawString(40, y, 'Original booking'); y -= 18
    c.setFont('Helvetica', 11)
    c.drawString(40, y, f"Route: {details['offer']['depart_airport']} → {details['offer']['arrive_airport']}"); y -= 16
    c.drawString(40, y, f"Flight: {details['offer']['airline']} — {details['offer']['flight_no']}"); y -= 16
    c.drawString(40, y, f"Amount paid: {br['currency']} {br['total']:,.2f}"); y -= 18

    ref = details.get('refund') or compute_refund(details)
    c.setFont('Helvetica-Bold', 12); c.drawString(40, y, 'Refund breakdown'); y -= 18
    c.setFont('Helvetica', 11)
    c.drawString(40, y, f"Non-refundable seat: {br['currency']} {ref.get('forfeited_seat',0):,.2f}"); y -= 16
    c.drawString(40, y, f"Penalty ({int(ref['penalty_rate']*100)}%): {br['currency']} {ref['penalty_amount']:,.2f}"); y -= 16
    c.drawString(40, y, f"Refund due: {br['currency']} {ref['refundable']:,.2f}"); y -= 16
    c.setFont('Helvetica', 9); c.drawString(40, y, f"Notes: {ref['notes']}")

    c.showPage(); c.save(); buf.seek(0)
    return send_file(buf, mimetype='application/pdf', as_attachment=True, download_name=f"receipt_cancel_{details['pnr']}.pdf")

@app.get('/api/health')
def health():
    return jsonify({'status':'ok'}), 200

if __name__ == '__main__':
    app.run(debug=True, port=5000)
